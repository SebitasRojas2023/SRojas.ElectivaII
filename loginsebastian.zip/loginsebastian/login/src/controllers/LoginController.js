const bcrypt = require('bcrypt');

function index(req, res) {
    res.render('login/index');
}

function register(req, res) {
  if(req.session.loggedin != true){
    res.render('login/register');
  }else{
    res.redirect('/');
  }
}

/*Funcion validar ingreso*/
function auth(req, res) {
const data = req.body;
  req.getConnection((err, conn) => {
    conn.query('SELECT * FROM users WHERE email = ?', [data.email], (err, userdata) => {
      if(userdata.length > 0) {
        userdata.forEach(element => {
          bcrypt.compare(data.password, element.password, (err, isMatch) => {
            if(!isMatch){
              res.render('login/index', {errpr: 'error contraseña Incorrecta'});
            }else{
              req.session.loggedin = true;
              req.session.name = element.name;
              res.redirect('/');
            }
          });
        });
      } else {
        res.render('login/index', {errpr: 'error Usuario no existe'});
      }
    });
  });
}

/*Funcion para cerrar la sesión */
function logout(req, res) {
  if (req.session.loggedin == true) {
    req.session.destroy();
  }
  res.redirect('/login');
}


function login(req, res){
  if(req.session.loggedin != true){
    res.render('login/index');
  }else{
    res.redirect('/');
  }
}


/*Función para crear usuario*/
function storeUser(req, res){
  const data = req.body;
  req.getConnection((err, conn) => {
    conn.query('SELECT * FFROM users WHERE email = ?', [data.email], (err, userdata) => {
        bcrypt.hash(data.password, 12).then(hash =>{
          data.password = hash;
          req.getConnection((err, conn)=> {
            conn.query('INSERT INTO users SET ?' , [data], (err, rows) => {
              res.redirect('/')
            })
          });
        });
    });
  })

}

module.exports = {
  index,
  register,
  auth,
  logout,
  storeUser,
  login
}
